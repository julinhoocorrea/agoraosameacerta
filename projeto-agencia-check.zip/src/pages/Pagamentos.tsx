export function Pagamentos() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-900">Pagamentos</h1>
      <p className="text-slate-600">Controle de pagamentos - Em desenvolvimento</p>
    </div>
  );
}
