export function Envios() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-900">Envios</h1>
      <p className="text-slate-600">Gestão de envios - Em desenvolvimento</p>
    </div>
  );
}
