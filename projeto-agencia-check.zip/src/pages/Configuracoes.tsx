import { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, TestTube, CheckCircle, XCircle, Settings } from 'lucide-react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { PixService, type PixProvider } from '@/services/pixService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';

const configSchema = z.object({
  defaultProvider: z.enum(['4send', 'inter']),
  fourSendToken: z.string().optional(),
  interClientId: z.string().optional(),
  interClientSecret: z.string().optional(),
  interPixKey: z.string().optional(),
  webhookUrl: z.string().url().optional().or(z.literal('')),
});

type ConfigForm = z.infer<typeof configSchema>;

export function Configuracoes() {
  const [testResults, setTestResults] = useState<{
    fourSend?: 'success' | 'error' | 'testing';
    inter?: 'success' | 'error' | 'testing';
  }>({});
  const [saveMessage, setSaveMessage] = useState<string>('');

  const pixService = PixService;

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    watch
  } = useForm<ConfigForm>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      defaultProvider: 'inter',
      fourSendToken: import.meta.env.VITE_4SEND_API_TOKEN || '',
      interClientId: import.meta.env.VITE_INTER_CLIENT_ID || '27dc6392-c910-4cf8-a813-6d9ee3c53d2c',
      interClientSecret: import.meta.env.VITE_INTER_CLIENT_SECRET || 'b27ef11f-89e6-4010-961b-2311afab2a75',
      interPixKey: import.meta.env.VITE_INTER_PIX_KEY || 'kwai@agenciacheck.com',
      webhookUrl: import.meta.env.VITE_WEBHOOK_URL || '',
    }
  });

  const onSubmit: SubmitHandler<ConfigForm> = (data) => {
    // Em uma aplicação real, isso seria salvo no backend ou localStorage
    localStorage.setItem('pixConfig', JSON.stringify(data));
    setSaveMessage('Configurações salvas com sucesso!');
    setTimeout(() => setSaveMessage(''), 3000);
  };

  const testConnection = async (provider: PixProvider) => {
    setTestResults(prev => ({ ...prev, [provider]: 'testing' }));

    try {
      // Teste básico de conectividade
      const testData = {
        amount: 0.01,
        description: 'Teste de conectividade',
        customerName: 'Teste Sistema',
        customerDocument: '00000000000',
        customerEmail: 'teste@sistema.com',
        customerPhone: '+5511999999999'
      };

      const result = await pixService.createPayment(testData, provider);

      if (result.paymentLink) {
        setTestResults(prev => ({ ...prev, [provider]: 'success' }));
      } else {
        setTestResults(prev => ({ ...prev, [provider]: 'error' }));
      }
    } catch (error) {
      console.error(`Erro ao testar ${provider}:`, error);
      setTestResults(prev => ({ ...prev, [provider]: 'error' }));
    }
  };

  const getTestIcon = (status?: 'success' | 'error' | 'testing') => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'testing':
        return <TestTube className="h-4 w-4 text-blue-500 animate-pulse" />;
      default:
        return <TestTube className="h-4 w-4 text-gray-400" />;
    }
  };

  const getTestBadge = (status?: 'success' | 'error' | 'testing') => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-600">Conectado</Badge>;
      case 'error':
        return <Badge variant="destructive">Erro</Badge>;
      case 'testing':
        return <Badge className="bg-blue-600">Testando...</Badge>;
      default:
        return <Badge variant="outline">Não testado</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-3"
      >
        <Settings className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Configurações PIX</h1>
          <p className="text-slate-600 mt-1">
            Configure as integrações com provedores PIX
          </p>
        </div>
      </motion.div>

      {saveMessage && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{saveMessage}</AlertDescription>
          </Alert>
        </motion.div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Configurações Gerais */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
              <CardDescription>
                Defina o provedor PIX padrão e configurações globais
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="defaultProvider">Provedor PIX Padrão</Label>
                <Select onValueChange={(value: PixProvider) => setValue('defaultProvider', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o provedor padrão..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inter">🏦 Banco Inter (Recomendado)</SelectItem>
                    <SelectItem value="4send">4send (Best4Send)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhookUrl">URL do Webhook (Opcional)</Label>
                <Input
                  id="webhookUrl"
                  placeholder="https://seudominio.com/webhook/pix"
                  {...register('webhookUrl')}
                  className={errors.webhookUrl ? 'border-red-500' : ''}
                />
                {errors.webhookUrl && (
                  <p className="text-sm text-red-500">{errors.webhookUrl.message}</p>
                )}
                <p className="text-xs text-gray-500">
                  URL para receber notificações de pagamentos confirmados
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Configurações 4send */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  4send (Best4Send)
                  {getTestBadge(testResults.fourSend)}
                </CardTitle>
                <CardDescription>
                  Configurações da API 4send para pagamentos PIX
                </CardDescription>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => testConnection('4send')}
                disabled={testResults.fourSend === 'testing'}
              >
                {getTestIcon(testResults.fourSend)}
                Testar Conexão
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fourSendToken">Token da API</Label>
                <Input
                  id="fourSendToken"
                  type="password"
                  placeholder="cm7domhw703b2q57w9fjaczfa"
                  {...register('fourSendToken')}
                />
                <p className="text-xs text-gray-500">
                  Token de acesso fornecido pela 4send
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Configurações Banco Inter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  Banco Inter
                  {getTestBadge(testResults.inter)}
                </CardTitle>
                <CardDescription>
                  Configurações da API PIX do Banco Inter
                </CardDescription>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => testConnection('inter')}
                disabled={testResults.inter === 'testing'}
              >
                {getTestIcon(testResults.inter)}
                Testar Conexão
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="interClientId">Client ID</Label>
                  <Input
                    id="interClientId"
                    placeholder="seu_client_id"
                    {...register('interClientId')}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="interClientSecret">Client Secret</Label>
                  <Input
                    id="interClientSecret"
                    type="password"
                    placeholder="seu_client_secret"
                    {...register('interClientSecret')}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="interPixKey">Chave PIX</Label>
                <Input
                  id="interPixKey"
                  placeholder="sua_chave@email.com"
                  {...register('interPixKey')}
                />
                <p className="text-xs text-gray-500">
                  Chave PIX cadastrada na sua conta Inter
                </p>
              </div>

              <Alert>
                <AlertDescription>
                  <strong>Importante:</strong> Para usar a API do Inter, você precisa:
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Ter uma conta Inter Empresas</li>
                    <li>Solicitar acesso à API PIX no portal do desenvolvedor</li>
                    <li>Configurar certificados SSL (em produção)</li>
                    <li>Ativar as permissões necessárias</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </motion.div>

        {/* Botões de Ação */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex gap-4"
        >
          <Button type="submit" className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Salvar Configurações
          </Button>
        </motion.div>
      </form>
    </div>
  );
}
